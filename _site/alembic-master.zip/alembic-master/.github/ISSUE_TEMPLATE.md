**Please read the [contributing guidelines](https://github.com/daviddarnes/alembic/blob/master/CONTRIBUTING.md) and [code of conduct](https://github.com/daviddarnes/alembic/blob/master/CODE_OF_CONDUCT.md) before creating an issue.**

Please prefix your issue with one of the following: **[Bug]** **[Proposal]** **[Question]**.

Please provide as much information as possible, ideally a summary to describe the issue and / or steps to reproduce the issue.
